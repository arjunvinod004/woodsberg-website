<?php

//echo "<pre>";print_r($_POST);die();
$admin_data = file_get_contents("./worldline_AdminData.json");
$mer_array = json_decode($admin_data, true);

$val = $_POST;

// Validation checks
$errors = array();

// Validate mobile number (10 or 12 digits)
if(empty($val['mobNo']) || !preg_match('/^[0-9]{10,12}$/', $val['mobNo'])) {
    $errors[] = "Enter valid 10 or 12 digit mobile number";
}

// Validate email
if(empty($val['email']) || !filter_var($val['email'], FILTER_VALIDATE_EMAIL)) {
    $errors[] = "Enter valid consumer email id";
}

// Validate account number
if(empty($val['accNo']) || !preg_match('/^[0-9]{9,18}$/', $val['accNo'])) {
    $errors[] = "Enter valid account number";
}

// Validate account holder name
if(empty($val['accountName']) || strlen($val['accountName']) > 50) {
    $errors[] = "Enter valid account holder name, length should not be greater than 50 characters";
}

// Validate account type
if(empty($val['accountType']) || !in_array($val['accountType'], ['Saving', 'Current'])) {
    $errors[] = "Enter valid account type, supported account types are \"Saving\" and \"Current\"";
}

// Validate IFSC code
if(empty($val['ifscCode']) || !preg_match('/^[A-Z]{4}0[A-Z0-9]{6}$/', $val['ifscCode'])) {
    $errors[] = "Enter valid IFSC";
}

// Added: Validate card fields only if provided and eMandate is disabled
if ($mer_array['enableEmandate'] != 1) {
    if (!empty($val['cardNumber']) && !preg_match('/^[0-9]{13,19}$/', $val['cardNumber'])) {
        $errors[] = "Enter valid card number (13-19 digits)";
    }
    if (!empty($val['expMonth']) && (!preg_match('/^(0[1-9]|1[0-2])$/', $val['expMonth']))) {
        $errors[] = "Enter valid expiry month (01-12)";
    }
    if (!empty($val['expYear']) && (!preg_match('/^[0-9]{4}$/', $val['expYear']))) {
        $errors[] = "Enter valid expiry year (YYYY, 4 digits)";
    }
    if (!empty($val['cvvCode']) && !preg_match('/^[0-9]{3,4}$/', $val['cvvCode'])) {
        $errors[] = "Enter valid CVV (3-4 digits)";
    }
}

// If there are validation errors, return them
if(!empty($errors)) {
    echo json_encode(array("error" => true, "messages" => $errors));
    exit;
}

if($mer_array['typeOfPayment'] == "TEST"){
    $val['amount'] = 1;
}

// Format dates properly
if($mer_array['enableEmandate'] == 1 && $mer_array['enableSIDetailsAtMerchantEnd'] == 1){
    $val['debitStartDate'] = date("d-m-Y");
    $val['debitEndDate'] = date("d-m-Y", strtotime($val['debitEndDate']));
} else {
    // Ensure dates are in correct format
    if (!empty($val['debitStartDate'])) {
    $val['debitStartDate'] = date("Y-m-d", strtotime($val['debitStartDate']));
}
if (!empty($val['debitEndDate'])) {
    $val['debitEndDate'] = date("Y-m-d", strtotime($val['debitEndDate']));
}

}

// Set default values for empty fields to avoid null values in hash
$val['cardNumber'] = !empty($val['cardNumber']) ? $val['cardNumber'] : '';
$val['expMonth'] = !empty($val['expMonth']) ? $val['expMonth'] : '';
$val['expYear'] = !empty($val['expYear']) ? $val['expYear'] : '';
$val['cvvCode'] = !empty($val['cvvCode']) ? $val['cvvCode'] : '';
$val['accNo'] = !empty($val['accNo']) ? $val['accNo'] : '';
$val['debitStartDate'] = !empty($val['debitStartDate']) ? $val['debitStartDate'] : '';
$val['debitEndDate'] = !empty($val['debitEndDate']) ? $val['debitEndDate'] : '';
$val['maxAmount'] = !empty($val['maxAmount']) ? $val['maxAmount'] : '';
$val['amountType'] = !empty($val['amountType']) ? $val['amountType'] : 'M';
$val['frequency'] = !empty($val['frequency']) ? $val['frequency'] : 'ADHO';  // Default frequency
$val['aadharNumber'] = !empty($val['aadharNumber']) ? $val['aadharNumber'] : '';

// Added: Force card fields to empty for eMandate to avoid format issues causing hash failures
if ($mer_array['enableEmandate'] == 1) {
    $val['cardNumber'] = '';
    $val['expMonth'] = '';
    $val['expYear'] = '';
    $val['cvvCode'] = '';
}

// Correct order for Worldline eNACH/Mandate hash based on Paynimo checkout.js documentation
$datastring = $val['mrctCode'] . "|" .
              $val['txn_id'] . "|" .
              $val['amount'] . "|" .
              $val['accNo'] . "|" .
              $val['custID'] . "|" .
              $val['mobNo'] . "|" .
              $val['email'] . "|" .
              $val['debitStartDate'] . "|" .
              $val['debitEndDate'] . "|" .
              $val['maxAmount'] . "|" .
              $val['amountType'] . "|" .
              $val['frequency'] . "|" .
              $val['cardNumber'] . "|" .
              $val['expMonth'] . "|" .
              $val['expYear'] . "|" .
              $val['cvvCode'] . "|" .
              $val['SALT'];

// Debug: Log the hash string (remove in production)
// error_log("Hash String: " . $datastring);

$hashed = hash('sha512', $datastring);
// error_log("Generated Hash: " . $hashed);

$data = array(
    "hash" => $hashed,
    "data" => array(
        $val['mrctCode'],         // 0 - Merchant Code
        $val['txn_id'],           // 1 - Transaction ID
        $val['amount'],           // 2 - Amount
        $val['debitStartDate'],   // 3 - Debit Start Date
        $val['debitEndDate'],     // 4 - Debit End Date
        $val['maxAmount'],        // 5 - Max Amount
        $val['amountType'],       // 6 - Amount Type
        $val['frequency'],        // 7 - Frequency
        $val['custID'],           // 8 - Customer ID
        $val['mobNo'],            // 9 - Mobile Number
        $val['email'],            // 10 - Email
        $val['accNo'],            // 11 - Account Number
        $val['returnUrl'],        // 12 - Return URL
        $val['name'],             // 13 - Customer Name
        $val['scheme'],           // 14 - Scheme
        $val['currency'],         // 15 - Currency
        $val['accountName'],      // 16 - Account Holder Name
        $val['ifscCode'],         // 17 - IFSC Code
        $val['accountType'],      // 18 - Account Type
        $val['cardNumber'],       // 19 - Card Number
        $val['expMonth'],         // 20 - Expiry Month
        $val['expYear'],          // 21 - Expiry Year
        $val['cvvCode'],          // 22 - CVV Code
        $val['aadharNumber']      // 23 - Aadhar Number
    )
);

echo json_encode($data);

?>